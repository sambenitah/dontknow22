<div class="row">
    <div style="margin-bottom: 50px;"  class="col-12 col-m-12 col-l-12">
        <p id="add-PagesTitle">Custom your error page</p>
    </div>
</div>

<section id="formAddPages">
        <?php $this->addModal("form", $ErrorPage);?>
</section>
