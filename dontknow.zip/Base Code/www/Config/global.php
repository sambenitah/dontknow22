<?php

return [
    'db' => [
        'driver' => '',
        'host' => '',
        'name' => '',
        'user' => '',
        'pwd' => '',
    ],
    'env' =>[
        'environment'=>''
    ],
    'mail' =>[
        'host'=>'',
        'username'=>'',
        'password'=>'',
        'port'=>'',
    ],
    'website' =>[
        'name' => ''
    ]
];