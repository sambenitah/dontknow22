<main>
    <section id="SectionOneAddUser">
        <h1 id="TitleAddLogUser">Create Your Account</h1>
        <p id="t1--AddLogUser">Please write your <?= $type ?> information</p>

        <?php $this->addModal("form", $form);?>

    </section>
</main>


