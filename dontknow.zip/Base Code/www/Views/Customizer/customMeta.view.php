<div class="row">
    <div  class="col-12 col-m-12 col-l-12">
        <p id="add-PagesTitle">Custom Meta of your WebSite</p>
    </div>
</div>

<section id="formAddPages">

    <?php $this->addModal("form", $Form);?>

</section>