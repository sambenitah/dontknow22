<main>
    <section id="SectionOneAddUser">
        <h1 id="TitleAddLogUser">Create Account</h1>
        <p id="t1--AddLogUser">Albready have an account ? <a id="a1--AddLogUser" href="#">Log in </a></p>


        <?php $this->addModal("form", $form);?>

    </section>
</main>


